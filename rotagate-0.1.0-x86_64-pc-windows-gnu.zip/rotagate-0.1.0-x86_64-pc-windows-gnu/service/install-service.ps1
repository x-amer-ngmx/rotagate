# Ручная установка службы Rotagate в Windows (PowerShell от администратора).
# Предпочтительный способ — `rotagated.exe install-service`, он делает то же самое.
#
#   .\install-service.ps1 -Exe "C:\Program Files\Rotagate\rotagated.exe"
#   .\install-service.ps1 -Uninstall

param(
    [string]$Exe = "",
    [string]$Config = "$env:ProgramData\rotagate\gateway.json",
    [string]$DataDir = "$env:ProgramData\rotagate\data",
    [switch]$Uninstall
)

$ErrorActionPreference = "Stop"

# По умолчанию ищем rotagated.exe рядом со скриптом, затем в корне архива (скрипт лежит в service\).
if (-not $Exe) {
    $Exe = @("$PSScriptRoot\rotagated.exe", "$PSScriptRoot\..\rotagated.exe") |
        Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $Exe) { throw "rotagated.exe не найден рядом со скриптом и в ..\ — укажите -Exe" }
    $Exe = (Resolve-Path $Exe).Path
}
$Name = "rotagated"

if ($Uninstall) {
    sc.exe stop $Name | Out-Null
    sc.exe delete $Name
    Write-Host "Служба $Name удалена. Конфиг и данные не тронуты."
    exit 0
}

New-Item -ItemType Directory -Force -Path (Split-Path $Config) | Out-Null
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null

$bin = "`"$Exe`" service-main --config `"$Config`" --data-dir `"$DataDir`""
New-Service -Name $Name -DisplayName "Rotagate Gateway" -BinaryPathName $bin `
    -StartupType Automatic `
    -Description "Rotagate — локальный ротирующий прокси-шлюз (HTTP + SOCKS5)"
# Перезапуск при сбое: 3 раза с паузой 5 с, сброс счётчика через сутки.
sc.exe failure $Name reset= 86400 actions= restart/5000/restart/5000/restart/5000 | Out-Null
Start-Service $Name
Write-Host "Служба $Name запущена. Лог: $DataDir\rotagated.log"
