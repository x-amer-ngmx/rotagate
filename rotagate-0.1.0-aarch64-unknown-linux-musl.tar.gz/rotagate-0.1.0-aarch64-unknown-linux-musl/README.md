# Rotagate

Rotagate — локальный прокси-шлюз с ротацией: HTTP и SOCKS5 принимаются на одном порту
(`127.0.0.1:1080`), трафик распределяется по пулу ваших upstream-прокси, а их живость
проверяется настоящими HTTP(S)-запросами.

## Состав архива

| Файл | Что это |
|---|---|
| `rotagated` (`rotagated.exe`) | служба-шлюз |
| `rotagate-ui` (`rotagate-ui.exe`) | приложение для мониторинга и управления (в архивах `*-musl` его нет: там только статически собранная служба) |
| `service/` | файлы службы: systemd unit / launchd plist / PowerShell-скрипт для Windows |
| `examples/gateway.json` | пример настроек шлюза (значения по умолчанию, каталог прокси `proxies/`) |
| `GUIDE.md` | **подробное руководство** — начните с него |
| `examples/proxies.sample.json` | пример формата списка прокси |
| `LICENSE` | лицензия: © 2026 Naguwal, все права защищены (проприетарная) |
| `THIRD-PARTY-LICENSES.md` | лицензии сторонних компонентов |

Рядом с архивами релиза лежит `SHA256SUMS`. Проверка: `sha256sum -c SHA256SUMS --ignore-missing`.

## Быстрый старт

**Самый короткий путь:**

* **С окном:** запустите `rotagate-ui`. При первом запуске откроется мастер «Добро пожаловать»:
  выберите «Автозапуск для текущего пользователя» (рекомендуется) или системную службу (root,
  потребуется пароль администратора) и нажмите «Установить и запустить».
* **В терминале:** запустите `./rotagated` без аргументов (Windows: `rotagated.exe`) — мастер задаст
  те же вопросы, установит службу и напечатает, куда класть прокси.

При первом запуске шлюз сам создаст папку настроек с `gateway.json`, **каталогом `proxies/`** и
`GUIDE.md`, а также папку данных с токеном Control API (Linux: `~/.config/rotagate/` и
`~/.local/share/rotagate/`; пути печатаются в выводе).

**Прокси:** положите свои файлы `*.json` (формат — `examples/proxies.sample.json`) в каталог
`proxies/` — сколько угодно файлов, шлюз подхватит каждый автоматически, без перезапуска. Или в
`rotagate-ui` → «Списки прокси» → «Импорт файла…» / перетащите `.json` в окно.

**Обновление со старой версии:** поля `proxy_files` и `notify.log` в `gateway.json` устарели — шлюз
запустится, но предупредит (лог, `rotagated check-config`). Файлы, перечисленные в `proxy_files`,
больше не загружаются: перенесите их в каталог `proxies/` и удалите поле.

Вариант вручную, с явными путями:

1. Положите `examples/gateway.json` в удобный каталог, рядом создайте каталог `proxies/` и положите
   туда свои файлы прокси.
2. Проверьте настройки: `rotagated check-config --config /путь/к/gateway.json`
   (код выхода 0 — ошибок нет).
3. Запустите шлюз в терминале: `rotagated run --config /путь/к/gateway.json`.
   Путь к конфигу можно задать и через `ROTAGATE_CONFIG`, каталог данных — через
   `--data-dir` или `ROTAGATE_DATA_DIR`. В каталоге данных хранятся `state.json` и токен
   Control API `control.token`.
4. Проверьте, что трафик идёт:
   `curl -x http://127.0.0.1:1080 https://httpbin.org/ip` или
   `curl --socks5-hostname 127.0.0.1:1080 https://httpbin.org/ip`.
5. Запустите `rotagate-ui`. Он подключится к Control API службы (`127.0.0.1:1090`)
   с токеном из каталога данных.

Полный список команд: `rotagated --help`.

## Установка как службы

```sh
sudo rotagated install-service --config /etc/rotagate/gateway.json --run-as rotagate  # системная служба
rotagated install-service --user                          # служба пользователя без root (Linux/macOS)
rotagated install-service --no-start                      # только записать файл службы
rotagated uninstall-service                               # удалить службу (конфиг и данные остаются)
```

`install-service` сам создаёт и включает systemd unit, launchd plist или Windows Service.
Файлы в `service/` — это образцы для ручной установки. Путь к бинарнику в них —
`/usr/local/bin/rotagated`. На Windows запустите
`service\install-service.ps1 -Exe <путь к rotagated.exe>` в PowerShell от имени
администратора.

## Безопасность

* Вход прокси слушает только loopback. Открыть его в сеть можно только явной настройкой
  `"allow_non_loopback": true`. Помните, что прокси без авторизации в сети быстро находят
  сканеры.
* Пароли прокси не пишутся в логи и не отдаются через API.

## Гео

Файл `dbip-country-lite.mmdb` — база стран DB-IP; службе он нужен рядом с `rotagated`.
IP Geolocation by DB-IP (https://db-ip.com), CC BY 4.0.
