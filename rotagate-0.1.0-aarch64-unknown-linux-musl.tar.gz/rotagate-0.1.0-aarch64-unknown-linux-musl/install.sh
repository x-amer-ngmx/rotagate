#!/bin/sh
# Установщик Rotagate для Linux (из распакованного архива).
#
#   ./install.sh                 — для текущего пользователя (~/.local), затем мастер службы
#   sudo ./install.sh --system   — для всех пользователей (/usr/local)
#   ./install.sh --no-setup      — только разложить файлы: без мастера и без обновления службы
#   ./install.sh --no-restart    — не трогать установленную службу и запущенные процессы
#   ./install.sh --yes           — не задавать вопросов
#   ./install.sh --uninstall     — удалить программу (настройки и списки прокси остаются)
#
# При обновлении установленная служба перезапускается на новом бинарнике, а
# мешающие ей процессы rotagated (старый код этого бинарника или держащие её
# порт) останавливаются — rotagated restart-service --takeover. Чужие программы
# и другие экземпляры rotagated не трогаются. Конфиги, каталог прокси и данные создаёт сама
# программа при первом запуске (см. GUIDE.md); установщик их не трогает.

set -eu

here="$(cd "$(dirname "$0")" && pwd)"
scope=user
run_setup=1
run_restart=1
assume_yes=0
action=install

usage() {
    sed -n '2,16p' "$0" | sed 's/^# \{0,1\}//'
}

while [ $# -gt 0 ]; do
    case "$1" in
        --system) scope=system ;;
        --user) scope=user ;;
        --no-setup) run_setup=0; run_restart=0 ;;
        --no-restart) run_restart=0 ;;
        -y|--yes) assume_yes=1 ;;
        --uninstall) action=uninstall ;;
        -h|--help) usage; exit 0 ;;
        *) echo "Неизвестный параметр: $1" >&2; usage >&2; exit 2 ;;
    esac
    shift
done

if [ "$scope" = system ]; then
    if [ "$(id -u)" -ne 0 ]; then
        echo "Для --system нужны права root: sudo $0 --system" >&2
        exit 1
    fi
    bindir=/usr/local/bin
    sharedir=/usr/local/share
else
    if [ "$(id -u)" -eq 0 ]; then
        echo "Установка «для пользователя» от root поставит программу в /root/.local."
        echo "Для всех пользователей используйте: sudo $0 --system"
    fi
    bindir="${XDG_BIN_HOME:-$HOME/.local/bin}"
    sharedir="${XDG_DATA_HOME:-$HOME/.local/share}"
fi

appdir="$sharedir/applications"
icondir="$sharedir/icons/hicolor"
docdir="$sharedir/doc/rotagate"

refresh_desktop_caches() {
    command -v update-desktop-database >/dev/null 2>&1 &&
        update-desktop-database -q "$appdir" 2>/dev/null || true
    command -v gtk-update-icon-cache >/dev/null 2>&1 &&
        gtk-update-icon-cache -q -t "$icondir" 2>/dev/null || true
}

# Атомарная замена: работает и когда старый бинарник сейчас запущен («Text file busy»).
put_exe() {
    install -m 0755 "$1" "$2.new.$$"
    mv -f "$2.new.$$" "$2"
}

if [ "$action" = uninstall ]; then
    if [ -x "$bindir/rotagated" ]; then
        echo "Удаляю службу (если установлена)…"
        if [ "$scope" = system ]; then
            "$bindir/rotagated" uninstall-service --system 2>/dev/null || true
        else
            "$bindir/rotagated" uninstall-service --user 2>/dev/null || true
        fi
    fi
    rm -f "$bindir/rotagated" "$bindir/rotagate-ui" "$bindir/dbip-country-lite.mmdb" "$appdir/rotagate.desktop"
    find "$icondir" -name 'rotagate.*' -path '*/apps/*' -delete 2>/dev/null || true
    rm -rf "$docdir"
    refresh_desktop_caches
    echo "Rotagate удалён. Настройки, списки прокси и данные не тронуты"
    echo "(Linux: ~/.config/rotagate и ~/.local/share/rotagate — удалите вручную, если не нужны)."
    exit 0
fi

[ -x "$here/rotagated" ] || { echo "Не найден $here/rotagated — запускайте install.sh из распакованного архива." >&2; exit 1; }

echo "Устанавливаю Rotagate ($scope) в $bindir"
mkdir -p "$bindir"
put_exe "$here/rotagated" "$bindir/rotagated"
has_ui=0
if [ -x "$here/rotagate-ui" ]; then
    put_exe "$here/rotagate-ui" "$bindir/rotagate-ui"
    has_ui=1
fi

# База стран прокси (DB-IP IP-to-Country Lite, CC BY 4.0): служба ищет её рядом с собой.
if [ -f "$here/dbip-country-lite.mmdb" ]; then
    install -m 0644 "$here/dbip-country-lite.mmdb" "$bindir/dbip-country-lite.mmdb.new.$$"
    mv -f "$bindir/dbip-country-lite.mmdb.new.$$" "$bindir/dbip-country-lite.mmdb"
fi

# Документация.
mkdir -p "$docdir"
for f in README.md GUIDE.md LICENSE-MIT LICENSE-APACHE; do
    [ -f "$here/$f" ] && install -m 0644 "$here/$f" "$docdir/$f"
done
[ -d "$here/examples" ] && cp -R "$here/examples" "$docdir/"

# Ярлык в меню приложений и значки (только если есть UI).
if [ "$has_ui" = 1 ] && [ -d "$here/share" ]; then
    if [ -d "$here/share/icons/hicolor" ]; then
        (cd "$here/share/icons/hicolor" && find . -name 'rotagate.*' -path '*/apps/*') |
            while read -r icon; do
                mkdir -p "$icondir/$(dirname "$icon")"
                install -m 0644 "$here/share/icons/hicolor/$icon" "$icondir/$icon"
            done
    fi
    if [ -f "$here/share/applications/rotagate.desktop" ]; then
        mkdir -p "$appdir"
        # Абсолютный путь: ~/.local/bin может отсутствовать в PATH графической сессии.
        sed "s|^Exec=rotagate-ui|Exec=$bindir/rotagate-ui|" \
            "$here/share/applications/rotagate.desktop" > "$appdir/rotagate.desktop"
        chmod 0644 "$appdir/rotagate.desktop"
    fi
    refresh_desktop_caches
    echo "Ярлык «Rotagate» добавлен в меню приложений."
fi

case ":$PATH:" in
    *":$bindir:"*) ;;
    *) echo "Внимание: $bindir нет в PATH. Добавьте в ~/.profile: export PATH=\"$bindir:\$PATH\"" ;;
esac

echo "Готово: $bindir/rotagated$( [ "$has_ui" = 1 ] && echo " и $bindir/rotagate-ui")"
echo "Руководство: $docdir/GUIDE.md"

# Обновление службы: остановить устаревшие процессы rotagated и перезапустить
# установленную службу на новом бинарнике. Логика (поиск по /proc, SIGTERM →
# SIGKILL, проверка портов, systemctl restart, проверка версии) — в самом
# rotagated, её же вызывает кнопка «Обновить службу» в UI.
# Коды: 0 — служба обновлена (или пользователь отказался), 1 — ошибка,
# 2 — нужен --yes, 3 — службы нет и процессов нет, 4 — службы нет, устаревшие
# процессы остановлены (или найденные не мешают).
service_rc=3
if [ "$run_restart" = 1 ]; then
    echo
    echo "Обновление службы…"
    if [ "$scope" = system ]; then
        set -- restart-service --takeover --system
    else
        set -- restart-service --takeover --user
    fi
    # Без терминала спросить нельзя — это наш собственный вызов, подтверждаем сами.
    if [ "$assume_yes" = 1 ] || [ ! -t 0 ]; then
        set -- "$@" --yes
    fi
    service_rc=0
    "$bindir/rotagated" "$@" || service_rc=$?
fi

case "$service_rc" in
    0)
        # Служба установлена и уже перезапущена — мастер не нужен.
        exit 0
        ;;
    3|4) ;;
    *)
        echo "Не удалось обновить службу (код $service_rc) — подробности выше." >&2
        echo "Повторить: $bindir/rotagated restart-service --takeover$( [ "$scope" = system ] && echo " --system")" >&2
        exit 1
        ;;
esac

if [ "$run_setup" = 0 ]; then
    echo "Дальше: rotagated setup — мастер установки службы автозапуска."
    exit 0
fi

if [ -t 0 ]; then
    echo
    if [ "$scope" = system ]; then
        "$bindir/rotagated" setup --scope system
    else
        "$bindir/rotagated" setup
    fi
else
    echo "Дальше: запустите «rotagated setup» в терминале или откройте Rotagate из меню приложений —"
    echo "мастер предложит установить службу автозапуска."
fi
